#! /vendor/bin/sh

MODDIR=${0%/*}

settings put global settings_enable_monitor_phantom_procs false
device_config set_sync_disabled_for_tests persistent
device_config put activity_manager max_cached_processes 2147483647
device_config put activity_manager max_phantom_processes 2147483647
settings put global activity_manager_constants max_cached_processes=2147483647
settings put global activity_manager_constants max_phantom_processes=2147483647

sh /system/bin/scene_swap_module.sh > /data/adb/swap_controller/swap.log
echo "模块开机自启动已完成！" >> /data/adb/swap_controller/swap.log

# 开机后trim一下，有助于尽量保持写入速度
busybox=/data/adb/magisk/busybox
if [[ -f $busybox ]]; then
  sm fstrim 2>/dev/null
  $busybox fstrim /data 2>/dev/null
  $busybox fstrim /cache 2>/dev/null
  $busybox fstrim /system 2>/dev/null
  # $busybox fstrim /data 2>/dev/null
  # $busybox fstrim /cache 2>/dev/null
  # $busybox fstrim /system 2>/dev/null
  sm fstrim 2>/dev/null
fi
